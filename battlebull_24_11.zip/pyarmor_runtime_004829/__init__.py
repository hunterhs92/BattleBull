# Pyarmor 9.0.5 (basic), 004829, 2024-11-24T13:57:25.681171
from .pyarmor_runtime import __pyarmor__
